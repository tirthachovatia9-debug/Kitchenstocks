# 🍳 KitchenStock — Complete Setup & Publish Guide

## What You're Building
A free Progressive Web App (PWA) that:
- Tracks your kitchen pantry stock
- Alerts when items need restocking
- Logs daily & monthly expenses
- Works on iPhone/Android as an app icon
- Shared with family via a free web link

---

## STEP 1 — Download the App Files

You have 3 files to download:
1. `index.html` — the entire app
2. `manifest.json` — makes it installable on iOS
3. `icon.svg` — the iOS home screen icon

> **iOS Icon Tip**: Convert `icon.svg` to PNG using a free tool like **CloudConvert.com**:
> - Upload `icon.svg` → Convert to PNG → Download at 512×512px
> - Save it as `icon.png` (and also as `icon-192.png` and `icon-512.png`)
> - Put all three PNG files in the same folder as `index.html`

---

## STEP 2 — Create a Free GitHub Account

1. Go to **github.com**
2. Click **Sign up** (top right)
3. Enter your email, create a password, choose a username
4. Verify your email
5. Choose the **Free** plan (it's free forever)

---

## STEP 3 — Create a New Repository

1. After logging in, click the **green "New"** button (top left) or go to **github.com/new**
2. Fill in:
   - **Repository name**: `kitchenstock` (all lowercase, no spaces)
   - **Description**: My kitchen pantry manager
   - **Visibility**: ✅ Public (required for free GitHub Pages)
   - ✅ Check **"Add a README file"**
3. Click **"Create repository"**

---

## STEP 4 — Upload Your App Files

1. Inside your new repository, click **"Add file" → "Upload files"**
2. Drag and drop these files:
   - `index.html`
   - `manifest.json`
   - `icon.png` (your converted icon)
   - `icon-192.png`
   - `icon-512.png`
3. Scroll down, write a commit message like `Add KitchenStock app`
4. Click **"Commit changes"**

---

## STEP 5 — Enable GitHub Pages (Free Hosting!)

1. In your repository, click **"Settings"** tab (top menu)
2. Scroll down to **"Pages"** in the left sidebar
3. Under **"Source"**, select:
   - Branch: **main**
   - Folder: **/ (root)**
4. Click **"Save"**
5. Wait 1–2 minutes, then your app will be live at:

   ```
   https://YOUR_USERNAME.github.io/kitchenstock/
   ```

   Example: `https://rahul.github.io/kitchenstock/`

---

## STEP 6 — Install on iPhone (Add to Home Screen)

Share this link with family. To install it like a native app:

1. Open the link in **Safari** (must be Safari, not Chrome)
2. Tap the **Share button** (box with arrow pointing up ↑)
3. Scroll down and tap **"Add to Home Screen"**
4. Change the name to **KitchenStock** if needed
5. Tap **"Add"**

✅ It now appears on the home screen with your spice-colored pot icon!

---

## STEP 7 — Share With Family

Send them this single link:
```
https://YOUR_USERNAME.github.io/kitchenstock/
```

Each family member can:
- Install it on their own iPhone/Android
- All data is stored **on each person's device** (no server needed)

> **Tip for shared data**: If you want all family members to see the SAME stock list, let me know and I can upgrade the app to use a free cloud database like Firebase or Supabase.

---

## STEP 8 — Update the App Later

When you want to make changes:
1. Edit the `index.html` file on GitHub directly (click the file → pencil icon)
2. OR use **GitHub Desktop** app (free) to edit locally and sync
3. Changes go live in ~1 minute automatically

---

## 💡 Quick Feature Reference

| Feature | How to Use |
|---|---|
| Add item | 🧺 Stock tab → "+ Add Item" button |
| Update stock qty | Tap − or + buttons on any item card |
| View restock alerts | 🔔 Alerts tab |
| Log a purchase/expense | 💰 Expenses tab → "+ Log Expense" |
| View monthly spending | 📊 Reports tab |
| Filter by category | Tap the category chips below search |

---

## 🆓 Everything Is FREE

| Service | Cost |
|---|---|
| GitHub account | Free |
| GitHub Pages hosting | Free |
| Custom domain (optional) | ₹800/year from GoDaddy/Namecheap |
| App data storage | Free (stored on device) |
| CloudConvert icon conversion | Free (10 conversions/day) |

---

## Troubleshooting

**App not loading?**
- Wait 5 minutes after enabling Pages, then hard-refresh

**Icon not showing on iPhone?**
- Make sure `icon.png` is in the same folder as `index.html`
- Re-add to home screen after uploading the icon

**Data not saving?**
- The app uses localStorage — data is per-device, per-browser
- Don't clear Safari data or you'll lose entries

---

*Built with HTML, CSS & JavaScript — no frameworks, no servers, no cost.*
